Supplementary Data 4. Primary longitudinal OU model inputs and design tables

OVERVIEW
Supplementary Data 4 contains the machine-readable input, audit, design, scaling, and transition-summary tables used to construct the primary longitudinal Ornstein–Uhlenbeck (OU) analyses and associated secondary endpoint analyses.

The files document the path from participant-level longitudinal measurements to model-ready transition records. They are provided to make participant inclusion, duplicate-time handling, ecological-context support, predictor construction, scaling, model specification, and transition structure transparent and reproducible.

PRIMARY LONGITUDINAL ENDPOINT
The primary longitudinal response is the continuous compositional trait x. The canonical model input is wave2_x_transition_table.csv, which contains consecutive within-participant transitions after participant reconciliation, chronological ordering, and preprocessing. Participant- and sampling-level summaries describe the longitudinal structure contributing to these transitions.

PRIMARY OU MODEL DESIGN
The design files contain participant-level predictors used by the primary OU ablation models, the model definitions used for comparison, and the scaling parameters applied to continuous predictors. The shuffled-context mapping is included as an explicit negative-control/permutation design object where applicable.

SECONDARY ORDINAL ENDPOINT
Files prefixed wave2_n_ document construction and auditing of the secondary ordinal n endpoint. These include ecological-context support, duplicate-time resolution, exclusions, state counts, the transition table, and transition matrices. These files provide complementary robustness analyses and should not be interpreted as the primary continuous-x OU input.

FILE GROUPS
1. Primary continuous-x longitudinal inputs
   wave2_x_transition_table.csv
   wave2_x_participant_summary.csv
   wave2_x_sampling_summary.csv
   wave2_x_exclusions.csv
   wave2_x_duplicate_time_audit.csv
   wave2_x_duplicate_resolution_audit.csv
   wave2_context_summary.csv

2. Primary OU model design
   wave2_participant_design_matrix.csv
   wave2_model_specifications.csv
   wave2_predictor_scaler_parameters.csv
   wave2_shuffled_context_mapping.csv

3. Secondary ordinal-n support and audit tables
   wave2_n_context_support.csv
   wave2_n_duplicate_time_audit.csv
   wave2_n_duplicate_resolution_audit.csv
   wave2_n_exclusions.csv
   wave2_n_participant_summary.csv
   wave2_n_state_counts.csv
   wave2_n_transition_table.csv
   wave2_n_transition_matrix_counts.csv
   wave2_n_transition_matrix_row_proportions.csv

INTERPRETATION NOTES
- Participant identifiers are the reconciled identifiers used in the revision workflow.
- Transition rows represent consecutive observations within participants after chronological ordering and preprocessing.
- Time intervals should be interpreted according to the definitions in the manuscript Methods and associated analysis scripts.
- Ecological-context variables are candidate ecological covariates inferred from participant-level tumor-microenvironment composition; they are not treated as leukemia subtypes, strict evolutionary taxa, or definitive biological entities.
- Predictor-scaler parameters should be applied exactly as recorded when reproducing model inputs.
- Duplicate-time audit and resolution files document preprocessing decisions and should be retained when reproducing cohort construction.
- Exclusion tables document observations or participants removed during endpoint-specific preprocessing.
- Transition-matrix counts and row proportions summarize the secondary ordinal-n endpoint and are not substitutes for the primary continuous-x transition table.
- Posterior draws, posterior predictive samples, model diagnostics, and leave-one-participant-out validation results are reported separately and are not part of Supplementary Data 4.

ABBREVIATIONS
OU, Ornstein–Uhlenbeck
TME, tumor microenvironment
LOPO, leave-one-participant-out
x, primary continuous compositional endpoint
n, secondary ordinal endpoint

REPRODUCIBILITY
These tables are intended to be used together with the analysis scripts and environment information deposited with the study's reproducibility materials. The accompanying Supplementary_Data_4_manifest.csv describes the role of each included file.

CITATION
When reusing these data, please cite the associated manuscript and its reproducibility repository/archival record.
